import skinny from './skinny.png';
import slender from './slender.png';
import sporty from './sporty.png';
import stocky from './stocky.png';
import patchy from './patchy.png';
import plain from './plain.png';
import spotted from './spotted.png';
import striped from './striped.png';

export { skinny, slender, sporty, stocky, patchy, plain, spotted, striped };